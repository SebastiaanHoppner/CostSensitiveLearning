summary.cslogit <- function (object)
{
  # Summarizing cslogit fits
  # -----------------------------------------------------------------------------------------------
  # Arguments:
  #   object   an object of class "cslogit"; a result of a call to the cslogit function
  # -----------------------------------------------------------------------------------------------
  # Value:
  #   summary.cslogit prints a summary of the "cslogit"-object
  # -----------------------------------------------------------------------------------------------
  # Written by Sebastiaan Höppner, 2019
  # -----------------------------------------------------------------------------------------------

  # check inputs
  if (missing(object)) {
    stop("argument 'object' is missing, with no default")
  }
  if (class(object) != "cslogit") {
    stop("argument 'object' must be of class 'cslogit'")
  }

  # print summary
  predictor_variables <- attr(object$terms, "dataClasses")[-1]
  factor_variables  <- names(which(predictor_variables == "factor"))
  numeric_variables <- names(which(predictor_variables != "factor"))
  n_factors  <- length(factor_variables)
  n_numerics <- length(numeric_variables)

  cat("SETTINGS -------------------------------------------------------------------------------\n")
  cat(paste("  - lambda =", object$lambda, "\n"))
  cat(paste("  - cost matrix (example) = \n"))
  print(object$example_cost_matrix)
  cat(paste("  - factor variables:\n"))
  for (i in 1:ceiling(n_factors / 5)) {
    cat(paste0("      ", paste0(factor_variables[(5*(i-1)+1):min((5*i), n_factors)], collapse = ", "),
               ifelse(i == ceiling(n_factors / 5), "\n", ",\n")))
  }
  cat(paste("  - numeric variables:\n"))
  for (i in 1:ceiling(n_numerics / 5)) {
    cat(paste0("      ", paste0(numeric_variables[(5*(i-1)+1):min((5*i), n_numerics)], collapse = ", "),
               ifelse(i == ceiling(n_numerics / 5), "\n", ",\n")))
  }
  cat("\n")
  cat("OPTIONS --------------------------------------------------------------------------------\n")
  cat(paste("  - algorithm =",   object$options$algorithm,   "\n"))
  cat(paste("  - maxeval =",     object$options$maxeval,     "\n"))
  cat(paste("  - ftol_rel =",    object$options$ftol_rel,    "\n"))
  cat(paste("  - xtol_rel =",    object$options$xtol_rel,    "\n"))
  cat(paste("  - print_level =", object$options$print_level, "\n"))
  cat(paste("  - check_data =",  object$options$check_data,  "\n"))
  cat(paste("  - lower bounds = "))
  cat(object$options$lb)
  cat(paste("\n  - upper bounds = "))
  cat(object$options$ub)
  cat("\n\n")
  cat("RESULTS --------------------------------------------------------------------------------\n")
  cat(paste0("  - message = ",  object$message, " (status ", object$status, ")\n"))
  cat(paste("  - iterations =", object$iterations, "\n"))
  cat(paste("  - time =",       object$time, "seconds\n"))
  cat(paste("  - objective =",  round(object$objective, 8), "\n"))
  cat(paste("  - average expected cost =",  round(object$average_expected_cost, 8), "\n"))
  cat(paste("  - coefficients = \n"))
  print(round(object$coefficients, 5))
  cat("\n")
}
